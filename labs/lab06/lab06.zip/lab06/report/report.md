---
## Front matter
title: "Отчет по лабораторной №6"
subtitle: "Мандатное разграничение прав в Linux"
author: "Камалиева Лия Дамировна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

развить навыки администрирования ОС Linux. Получить первое прак-тическое знакомство с технологией SELinux1. Проверить работу SELinx на практике совместно с веб-сервером Apache.

# Задание

ознакомиться с созданием новых пользователей

# Теоретическое введение


# Выполнение лабораторной работы

## 1.1 создание файлов

Шаг 1. входим в систему

![рис.1.1](image/5.3.jpg)

Шаг 2. пишем программу

![рис.1.2](image/5.1.png)

Шаг 3. от иени суперпользователя выполняем программы

![рис.1.3](image/5.4.jpg)

Шаг 4. создаем программу readfile.c

![рис.1.4](image/5.2.png)

Шаг 5. сменяем пользователя

![рис.1.5](image/5.5.jpg)






# Выводы

мы поработали с атрибутами файлов и пользователями

# Список литературы{.unnumbered}
