---
## Front matter
title: "Отчёта по лабораторной работе №3"
subtitle: "Дискреционное разграничение прав в Linux. Два пользователя"
author: "Камалиева Лия Дамировна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

 Получение практических навыков работы в консоли с атрибутами фай-
лов для групп пользователей

# Задание

ознакомиться с созданием новых пользователей

# Теоретическое введение


# Выполнение лабораторной работы

## 1.1 создание guest2

Шаг 1. Заходим в root и создаем guest

![рис.1.1](image/3.1.png)

Шаг 2. добавляем guest2 в guest и выполняем вход в две учетные записи

![рис.1.2](image/3.2.png)

Шаг 3. и выполняем вход в две учетные записи используем pwd чтобы посмотреть директорию

![рис.1.3](image/3.3.png)

Шаг 4. Смотрим в какой группе находится guest, guest2

![рис.1.4](image/3.4.png)

Шаг 5. смотрим параметры у guest2

![рис.1.5](image/3.5.png)

Шаг 6. от имени пользователя guest2  выполняем регистрацию пользователя guest2 

![рис.1.6](image/3.6.png)

Шаг 7. меняя атрибуты директории dir1, file1 от имени пользователя guest и делая проверку заполняем таблицу 2. на основании заполненной таблицы мы определяем, те или иные минимально необходимые права

![рис.1.7](image/3.7.png)


![рис.1.8](image/3.8.png)

## 1.2 Заполнение таблицы

Шаг 1. Обозначения в таблице:
(1) Создание файла
(2) Удаление файла
(3) Запись в файл
(4) Чтение файла
(5) Сменадиректории
(6) Просмотр файлов в директории 
(7) Переименование файл
(8) Смена атрибутов файла

![рис.1.9](image/3.9.jpg)


![рис.1.10](image/3.10.jpg)


![рис.1.11](image/3.11.jpg)


![рис.1.12](image/3.12.jpg)


![рис.1.13](image/3.13.jpg)


![рис.1.14](image/3.14.jpg)





# Выводы

мы поработали с атрибутами файлов и пользователями

# Список литературы{.unnumbered}
