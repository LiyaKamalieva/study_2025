---
## Front matter
lang: ru-RU
title: Лабораторная работа №3
author:
  - Камалиева Лия Дамировна\inst{1}
institute:
   \inst{1}Российский университет дружбы народов, Москва, Россия
date: 28 февраля, 2024

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---


## Цели и задачи

Дискреционное разграничение прав в Linux. Два пользователя
 Получение практических навыков работы в консоли с атрибутами файлов для групп пользователей

# Выполнение лабораторной работы

## Заходим в root и создаем guest

![рис.1.1](image/3.1.png){ #fig:001 width=70% }

## добавляем guest2 в guest и выполняем вход в две учетные записи

![рис.1.2](image/3.2.png){ #fig:002 width=70% }

## смотрим параметры у guest2

![рис.1.3](image/3.5.png){ #fig:003 width=70% }


## от имени пользователя guest2  выполняем регистрацию пользователя guest2 

![рис.1.4](image/3.6.png){ #fig:004 width=70% }

## заполняем таблицу

![рис.1.5](image/3.9.jpg){ #fig:005 width=70% }



![рис.1.6](image/3.10.jpg){ #fig:006 width=70% }


![рис.1.7](image/3.11.jpg){ #fig:007 width=70% }




#Выводы


## Итоговый слайд (вывод)

мы поработали с атрибутами файлов и пользователями
