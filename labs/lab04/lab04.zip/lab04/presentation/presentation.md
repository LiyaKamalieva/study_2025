---
## Front matter
lang: ru-RU
title: Структура научной презентации
subtitle: Простейший шаблон
author:
  - Камалиева Лия Дамировна
institute:
  - Российский университет дружбы народов, Москва, Россия

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---

# Информация

## Докладчик

:::::::::::::: {.columns align=center}
::: {.column width="70%"}

  * Камалиева Лия Дамировна
  * студентка
  * Российский университет дружбы народов

:::
::: {.column width="30%"}

:::
::::::::::::::

# Вводная часть


## Цели и задачи

 Получение практических навыков работы в консоли с атрибутами фай-
лов для групп пользователей

## Шаг 1 определяем расширенные атрибуты


![рис 1](image/4.1.png){#fig:001 width=70%}

## Шаг 2 установка прав доступа, попытка установить расширенный атрибут


![рис 2](image/4.2.png){#fig:002 width=70%}

## Шаг 3. проверка установленных атрибутов


![рис 3](image/4.3.png){#fig:001 width=70%}

##Шаг 4. снятие атрибута, установка прав 000


![рис 4](image/4.5.png){#fig:001 width=70%}

## Вывод

мы поработали с атрибутами файлов и пользователями


