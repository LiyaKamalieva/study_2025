---
## Front matter
title: "Отчёта по лабораторной работе №4"
subtitle: "Дискреционное разграничение прав в Linux. Расширенные атрибуты"
author: "Камалиева Лия Дамировна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

 Получение практических навыков работы в консоли с атрибутами фай-
лов для групп пользователей

# Задание

ознакомиться с созданием новых пользователей

# Теоретическое введение


# Выполнение лабораторной работы


Шаг 1. определяем расширенные атрибуты

![рис.1.1](image/4.1.png)

Шаг 2.  установка прав доступа, попытка установить расширенный атрибут

![рис.1.2](image/4.2.png)

Шаг 3. проверка установленных атрибутов

![рис.1.3](image/4.3.png)

Шаг 4. попытка удаления, изменения файла

![рис.1.4](image/4.4.png)

Шаг 5. снятие атрибута, установка прав 000

![рис.1.5](image/4.5.png)

Шаг 6. повторение действий с атрибутом

![рис.1.6](image/4.6.png)


# Выводы

мы поработали с атрибутами файлов и пользователями

# Список литературы{.unnumbered}
