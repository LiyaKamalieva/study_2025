---
## Front matter
lang: ru-RU
title: Отчет по лабораторной №7
author:
  - Камалиева Лия Дамировна\inst{1}
institute:
   \inst{1}Российский университет дружбы народов, Москва, Россия
date: 28 февраля, 2025

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---


## Цели и задачи

Развить навыки администрирования ОС Linux. Получить первое практическое знакомство с технологией SELinux1. Проверить работу SELinx на практике совместно с веб-сервером Apache.

# Выполнение лабораторной работы


##  создание файлов



![virtualMashine рис.1.1](image/5.3.jpg){ #fig:001 width=70% }


## пишем программу

![рис.1.2](image/5.1.png{ #fig:002 width=70% }


## от имени суперпользователя выполняем программы

![рис.1.3](image/5.4.jpg){ #fig:003 width=70% }


## создаем программу readfile.c

![рис.1.4](image/5.2.png){ #fig:004 width=70% }







#Выводы


## Итоговый слайд (вывод)

мы поработали с атрибутами файлов и пользователями


